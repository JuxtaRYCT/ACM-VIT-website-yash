/**
 * Astro Liquid Glass - Component Type Definitions
 *
 * Usage:
 * import type { SheetProps, ToggleProps } from 'astro-liquid-glass/types';
 */

// ============================================
// INTERACTIVE CONTROLS
// ============================================

export interface ToggleProps {
  id?: string;
  name?: string;
  checked?: boolean;
  disabled?: boolean;
  label?: string;
  class?: string;
}

export interface SliderProps {
  id?: string;
  name?: string;
  value?: number;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
  label?: string;
  showValue?: boolean;
  class?: string;
}

export interface Segment {
  id: string;
  label: string;
}

export interface SegmentedControlProps {
  segments: Segment[];
  selected?: string;
  name?: string;
  class?: string;
}

export interface ProgressProps {
  value?: number;
  max?: number;
  indeterminate?: boolean;
  variant?: 'linear' | 'circular' | 'dots';
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  showValue?: boolean;
  class?: string;
}

export interface BadgeProps {
  count?: number;
  max?: number;
  dot?: boolean;
  variant?: 'default' | 'glass' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  class?: string;
}

// ============================================
// PRESENTATIONS
// ============================================

export interface SheetProps {
  id: string;
  title?: string;
  size?: 'small' | 'medium' | 'large' | 'full';
  showHandle?: boolean;
  showClose?: boolean;
  class?: string;
}

export interface AlertAction {
  label: string;
  action?: string;
  primary?: boolean;
  destructive?: boolean;
}

export interface AlertProps {
  id: string;
  title: string;
  message?: string;
  actions?: AlertAction[];
  leftAligned?: boolean;
  stacked?: boolean;
  class?: string;
}

export interface ToastProps {
  id: string;
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error';
  action?: string;
  actionLabel?: string;
  duration?: number;
  class?: string;
}

// ============================================
// NAVIGATION
// ============================================

export interface NavLink {
  href: string;
  label: string;
}

export interface HeaderProps {
  siteTitle: string;
  navLinks?: NavLink[];
  currentPath?: string;
  floating?: boolean;
  class?: string;
}

export interface TabItem {
  id: string;
  label: string;
  icon?: string;
  href?: string;
}

export interface TabBarProps {
  items: TabItem[];
  activeTab?: string;
  minimizeOnScroll?: boolean;
  class?: string;
}

// ============================================
// CONTENT
// ============================================

export interface HeroProps {
  image: string;
  alt?: string;
  title?: string;
  subtitle?: string;
  height?: string;
  overlay?: boolean;
  glassCard?: boolean;
  backgroundExtend?: boolean;
  class?: string;
}

export interface GlassCardProps {
  variant?: 'default' | 'chapter' | 'glossary' | 'reference' | 'expert';
  href?: string;
  class?: string;
}

