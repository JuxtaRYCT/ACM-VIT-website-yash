import type { AstroIntegration } from 'astro';

export interface LiquidGlassOptions {
  /**
   * Include the global CSS styles
   * @default true
   */
  includeCSS?: boolean;

  /**
   * Include the JS enhancements for interactive effects
   * @default true
   */
  includeJS?: boolean;

  /**
   * Primary brand color (CSS color value)
   * @default '#007AFF'
   */
  primaryColor?: string;

  /**
   * Secondary brand color (CSS color value)
   * @default '#5856D6'
   */
  secondaryColor?: string;
}

// Sanitize CSS color values to prevent injection
function sanitizeCSSColor(color: string): string | null {
  // Allow hex colors, rgb/rgba, hsl/hsla, and named colors
  const validPatterns = [
    /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/, // hex
    /^rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)$/, // rgb
    /^rgba\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*[\d.]+\s*\)$/, // rgba
    /^hsl\(\s*\d{1,3}\s*,\s*[\d.]+%\s*,\s*[\d.]+%\s*\)$/, // hsl
    /^hsla\(\s*\d{1,3}\s*,\s*[\d.]+%\s*,\s*[\d.]+%\s*,\s*[\d.]+\s*\)$/, // hsla
    /^[a-zA-Z]+$/, // named colors (no special chars)
  ];

  const trimmed = color.trim();
  if (validPatterns.some(pattern => pattern.test(trimmed))) {
    return trimmed;
  }

  return null;
}

export default function liquidGlass(options: LiquidGlassOptions = {}): AstroIntegration {
  const {
    includeCSS = true,
    includeJS = true,
    primaryColor,
    secondaryColor,
  } = options;

  // Sanitize color inputs
  const safePrimaryColor = primaryColor ? sanitizeCSSColor(primaryColor) : null;
  const safeSecondaryColor = secondaryColor ? sanitizeCSSColor(secondaryColor) : null;

  return {
    name: 'astro-liquid-glass',
    hooks: {
      'astro:config:setup': ({ injectScript, logger }) => {
        logger.info('Setting up Liquid Glass design system...');

        // Warn about invalid colors
        if (primaryColor && !safePrimaryColor) {
          logger.warn(`Invalid primaryColor "${primaryColor}" - must be a valid CSS color`);
        }
        if (secondaryColor && !safeSecondaryColor) {
          logger.warn(`Invalid secondaryColor "${secondaryColor}" - must be a valid CSS color`);
        }

        // Inject CSS
        if (includeCSS) {
          injectScript(
            'page-ssr',
            `import 'astro-liquid-glass/styles/index.css';`
          );
        }

        // Inject custom color overrides if provided (sanitized)
        if (safePrimaryColor || safeSecondaryColor) {
          const colorOverrides = `:root {
            ${safePrimaryColor ? `--color-primary: ${safePrimaryColor};` : ''}
            ${safeSecondaryColor ? `--color-secondary: ${safeSecondaryColor};` : ''}
          }`;
          injectScript(
            'page-ssr',
            `const style = document.createElement('style');
             style.textContent = \`${colorOverrides}\`;
             document.head.appendChild(style);`
          );
        }

        // Inject JS enhancements
        if (includeJS) {
          injectScript(
            'page',
            `import 'astro-liquid-glass/scripts/liquid-glass.js';`
          );
        }
      },

      'astro:config:done': ({ config, logger }) => {
        // Validate configuration
        logger.info('Liquid Glass integration loaded successfully');

        // Log helpful info
        if (config.output === 'static') {
          logger.info('Static output mode detected - all components will be pre-rendered');
        }
      },
    },
  };
}

// Note: Components and layouts should be imported directly from their paths:
// import GlassCard from 'astro-liquid-glass/components/GlassCard.astro';
// import BaseLayout from 'astro-liquid-glass/layouts/BaseLayout.astro';
//
// Or use the integration in astro.config.mjs:
// import liquidGlass from 'astro-liquid-glass';
// export default defineConfig({
//   integrations: [liquidGlass()],
// });
