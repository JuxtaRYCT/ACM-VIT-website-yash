# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-01-25

### Added

- Initial release of Astro Liquid Glass design system
- 27 Astro components (Toggle, Slider, Sheet, Button, Card, etc.)
- 3 layout components (BaseLayout, BookLayout, ReferenceLayout)
- Complete CSS design system with 11 modular stylesheets
- Glass morphing effects with dynamic blur, opacity, and saturation
- Motion-responsive highlights via DeviceOrientation API
- Touch feedback and gesture support
- iOS-style bottom sheets with drag-to-resize
- Dark mode support
- Accessibility features (reduced motion, reduced transparency, high contrast)
- Battery saver mode detection
- WCAG contrast verification utilities
- TypeScript support with full type declarations
- Astro integration for automatic CSS/JS injection

### Components

- ActionSheet
- Alert
- Badge
- Button
- Card (GlassCard)
- ChapterCard
- Chip
- ContextMenu
- ExpertCard
- FAQ
- Footer
- GlossaryTerm
- Header
- Hero
- MeshGradient
- Progress
- ReferenceItem
- SearchInput
- SegmentedControl
- Sheet
- Sidebar
- Slider
- TabBar
- TableOfContents
- Toast
- Toggle
- Toolbar
